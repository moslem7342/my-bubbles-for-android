package com.moslem.testbubbles;

import android.app.Activity;
import android.content.Context;
import android.view.inputmethod.InputMethodManager;

public class SoftKeyboardClass {

    SoftKeyboardClass instant;
    Context context;

    public SoftKeyboardClass(Context context){
       //getInstant(context);
        this.context=context;

    }
    public SoftKeyboardClass(){



    }


    public SoftKeyboardClass getInstant(Context context) {
        if(instant==null)
            instant=new SoftKeyboardClass();
        return instant;
    }

    public void hideKeyboard(Activity activity) {

            InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (inputManager != null&& activity.getCurrentFocus()!=null) {
                inputManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
            }

    }
    public void showKeyboard(){
        InputMethodManager inputMethodManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputMethodManager != null) {
            inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
        }
    }


}
