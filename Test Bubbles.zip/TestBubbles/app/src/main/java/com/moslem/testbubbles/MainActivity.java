package com.moslem.testbubbles;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.Person;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewStub;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;




import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    BubblesManager bubblesManager;

    @Override
    protected void onDestroy() {
        bubblesManager.recycle();
        super.onDestroy();
    }
    ViewStub viewStubCards;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bubblesManager = new BubblesManager.Builder(this)
                .setTrashLayout(R.layout.bubble_trash)
                .build();
        bubblesManager.initialize();




        AppCompatButton button=findViewById(R.id.bubble_btr);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              BubbleLayout bubbleView = (BubbleLayout) LayoutInflater
                        .from(MainActivity.this).inflate(R.layout.bubble_layout, null);
                bubbleView.setShouldStickToWall(false);
                viewStubCards=bubbleView.findViewById(R.id.bubble_dialog_layout);

              bubbleView.setOnBubbleClickListener(new BubbleLayout.OnBubbleClickListener() {
                  @Override
                  public void onBubbleClick(BubbleLayout bubble) {
                      //new SoftKeyboardClass(MainActivity.this).showKeyboard();

         /*            View view= bubbleView.findViewById(R.id.bubble_layout_text_input);
                     if(view.getVisibility()==View.VISIBLE)
                            view.setVisibility(View.GONE);
                     else
                         view.setVisibility(View.VISIBLE);*/
                      //List<String> searchListItems = new ArrayList<>();
                      //SearchableDialog  searchableDialog = new SearchableDialog(this, searchListItems, "Title");
                  new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                          @Override
                          public void run() {
                              Animation animation = AnimationUtils.makeInAnimation(MainActivity.this, true);

                              animation.setDuration(300);


                              View cardsLayout=viewStubCards.inflate();
                             // findViewsCards(cardsLayout);
                              cardsLayout.startAnimation(animation);
                             EditText editText= cardsLayout.findViewById(R.id.bubble_dialog_edit_text);

                                  editText

                                          .setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View v) {
                                      new SoftKeyboardClass(MainActivity.this).showKeyboard();
                                      Log.d("TAG", "onClick: cardsLayout");
                                  }
                              });





                          }
                      },1000);
                  }
              });

                bubblesManager.addBubble(bubbleView, 250, 500);


            }
        });
    }
}